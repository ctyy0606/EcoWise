"""
EcoWise 宿舍助理 - 全局配置文件
================================
所有"会变的参数"都集中在这里:
- 涂鸦云 API 凭证
- 设备(插座)清单,以及每个插座对应哪个室友
- 违规检测的功率阈值
- 电价
- 各 DP 的单位换算系数
"""
from typing import Dict

# ============ 1. 涂鸦云开放平台凭证 ============
ACCESS_ID = "kfdcessnjag4fgv4wtru"
ACCESS_SECRET = "2c38065612014ee6801451e82cd66d54"
API_ENDPOINT = "https://openapi.tuyacn.com"  # 中国区


# ============ 2. 插座清单 ============
# key 是设备 ID(涂鸦开发者平台 -> 设备管理里能看到)
# value 是这个插座的"友好名字"和它对应的室友
DEVICES: Dict[str, dict] = {
    "6c3780ebe5a98ff4a0n5rd": {
        "name": "插座1(同学A-电脑桌)",
        "owner": "同学A",
    },
    # 新增插座照抄格式:
    # "xxxxxxxxxxxxxxxxxxxx": {
    #     "name": "插座2(同学B-床边)",
    #     "owner": "同学B",
    # },
}


# ============ 3. 违规检测阈值(单位:瓦 W) ============
VIOLATION_THRESHOLDS = {
    "warning_watts": 450,    # 限电预警线
    "violation_watts": 800, # 违规告警线
}


# ============ 4. 电价 ============
ELECTRICITY_PRICE_PER_KWH = 0.55  # 元/度


# ============ 5. DP 单位换算系数 ============
# 涂鸦各 DP 原始值 → 物理量的换算关系
# 注意:不同厂商固件可能不一致,实测后调整
#
# add_ele: 原始值 × 0.001 = 度(kWh)
#   例: 原始 6  →  6 × 0.001 = 0.006 度 = 6 Wh
#   (App 显示 0.006,代码里 6 Wh,其实是同一个值)
#
# cur_power: 实测原始值 200,实际 20W → 原始值 × 0.1 = W
#   例: 原始 200  →  200 × 0.1 = 20 W
#
# cur_voltage: 原始值 × 0.1 = V
#   例: 原始 2205  →  2205 × 0.1 = 220.5 V
#
# cur_current: 原始值单位是 mA,无需换算
ADD_ELE_RAW_UNIT_KWH = 0.001  # 1 原始单位 = 0.001 度
POWER_RAW_UNIT_W = 0.1        # 1 原始单位 = 0.1 W  ← 修复功率 ×10 问题
VOLTAGE_RAW_UNIT_V = 0.1     # 1 原始单位 = 0.1 V
