"""
EcoWise 宿舍助理 - 违规电器检测(L0 功率阈值法)
===========================================
    功率 > 800W  → 违规告警(疑似热得快/电水壶/电热毯)
    功率 > 450W  → 限电预警(可能要跳闸)
    其他         → 正常
"""
from typing import Dict, List

import config


def check_power_violation(power_w) -> Dict:
    """根据当前功率判断是否有违规/预警。"""
    if power_w is None:
        return {
            "level": "normal",
            "title": "数据缺失",
            "message": "当前无法获取功率数据,可能设备离线。",
            "power_w": None,
        }

    if power_w > config.VIOLATION_THRESHOLDS["violation_watts"]:
        return {
            "level": "violation",
            "title": "违规电器告警",
            "message": (
                f"当前功率 {power_w}W,超过 {config.VIOLATION_THRESHOLDS['violation_watts']}W 红线,"
                f"疑似使用热得快/电水壶/电热毯等违规电器,请立即关闭!"
            ),
            "power_w": power_w,
        }

    if power_w > config.VIOLATION_THRESHOLDS["warning_watts"]:
        return {
            "level": "warning",
            "title": "限电预警",
            "message": (
                f"当前功率 {power_w}W,接近宿舍限电阈值,"
                f"建议关闭部分大功率设备,避免跳闸。"
            ),
            "power_w": power_w,
        }

    return {
        "level": "normal",
        "title": "用电正常",
        "message": f"当前功率 {power_w}W,处于安全范围。",
        "power_w": power_w,
    }


def detect_all_devices(devices_data: List[Dict]) -> List[Dict]:
    """对所有插座批量做违规检测,把结果合并到原数据里。"""
    results = []
    for dev in devices_data:
        if "error" in dev:
            results.append(dev)
            continue
        if not dev.get("online") or not dev.get("switch_on"):
            violation = check_power_violation(None)
        else:
            violation = check_power_violation(dev.get("power_w"))
        dev_with_violation = {**dev, "violation": violation}
        results.append(dev_with_violation)
    return results
