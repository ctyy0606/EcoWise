"""
EcoWise 宿舍助理 - 涂鸦云 API 封装
================================
只负责一件事:从涂鸦云拉取插座实时数据,并做单位换算。
"""
from typing import Optional, Dict
from datetime import datetime

from tuya_connector import TuyaOpenAPI

import config


_openapi: Optional[TuyaOpenAPI] = None


def _get_openapi() -> TuyaOpenAPI:
    """获取(或首次创建)涂鸦云连接对象。"""
    global _openapi
    if _openapi is None:
        _openapi = TuyaOpenAPI(
            config.API_ENDPOINT,
            config.ACCESS_ID,
            config.ACCESS_SECRET,
        )
        _openapi.connect()
        print("[涂鸦云] 已建立连接")
    return _openapi


def get_device_data(device_id: str) -> Dict:
    """
    拉取单个插座的实时数据,做单位换算后返回。

    返回字段:
        device_id, device_name, owner,
        online, switch_on,
        power_w, voltage_v, current_ma,
        energy_kwh, energy_wh,
        timestamp
    """
    api = _get_openapi()

    # 1) 先查设备信息(判断在线状态)
    info_resp = api.get(f"/v1.0/devices/{device_id}")
    info = info_resp.get("result", {}) or {}
    is_online = info.get("online", False)

    # 2) 拉取设备 DP 状态
    status_resp = api.get(f"/v1.0/devices/{device_id}/status")
    result = status_resp.get("result", []) or []

    power_raw = None
    add_ele_raw = None
    voltage_raw = None
    current_raw = None
    switch_on = None

    for item in result:
        code = item.get("code")
        value = item.get("value")
        if code == "cur_power":
            power_raw = value
        elif code == "add_ele":
            add_ele_raw = value
        elif code == "cur_voltage":
            voltage_raw = value
        elif code == "cur_current":
            current_raw = value
        elif code == "switch_1":
            switch_on = bool(value)

    # 3) 单位换算(系数在 config.py 里,改系数不用改这里)
    energy_kwh = (
        add_ele_raw * config.ADD_ELE_RAW_UNIT_KWH
        if add_ele_raw is not None else None
    )
    energy_wh = energy_kwh * 1000.0 if energy_kwh is not None else None
    # ↓↓↓ 关键修复:功率也要乘换算系数(0.1)
    # 之前直接拿原始值,导致 20W 显示成 200W
    power_w = (
        power_raw * config.POWER_RAW_UNIT_W
        if power_raw is not None else None
    )
    voltage_v = (
        voltage_raw * config.VOLTAGE_RAW_UNIT_V
        if voltage_raw is not None else None
    )

    dev_meta = config.DEVICES.get(device_id, {})

    return {
        "device_id": device_id,
        "device_name": dev_meta.get("name", f"未命名设备-{device_id[:6]}"),
        "owner": dev_meta.get("owner", "未知"),
        "online": is_online,
        "switch_on": switch_on,
        "power_w": round(power_w, 1) if power_w is not None else None,
        "voltage_v": round(voltage_v, 1) if voltage_v is not None else None,
        "current_ma": current_raw,
        "energy_kwh": energy_kwh,
        "energy_wh": energy_wh,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }


def get_all_devices() -> list:
    """一次性拉取所有插座数据,单个失败不影响整体。"""
    results = []
    for device_id in config.DEVICES.keys():
        try:
            results.append(get_device_data(device_id))
        except Exception as e:
            results.append({
                "device_id": device_id,
                "device_name": config.DEVICES[device_id].get("name", device_id),
                "owner": config.DEVICES[device_id].get("owner", "未知"),
                "online": False,
                "error": str(e),
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
    return results
